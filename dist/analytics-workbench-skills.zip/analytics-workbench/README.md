# Analytics workbench skills

A portable, agent-agnostic workflow for shared data preparation, distinct investigations, and repeatable delivery packages. Git tracks analytical code; GitHub hosting is not required.

## Included artifacts

- [workbench-init](.agents/skills/workbench-init/SKILL.md): initialize a project and establish an investigation when its business question is available.
- [Project AGENTS.md template](.agents/skills/workbench-init/assets/workbench/AGENTS.md): govern everyday analysis and recordkeeping.
- [workbench-package](.agents/skills/workbench-package/SKILL.md): create, revise, or explicitly release a delivery package.

External dependency: `grilling` must already be installed and discoverable by the agent. It is not included or redistributed in this bundle. Workbench instructions invoke it directly, one question at a time, preserving settled answers.

## Transfer to the work machine

Copy the complete `workbench-init` and `workbench-package` directories from `.agents/skills/` into `~/.agents/skills/` on the work machine:

```text
~/.agents/skills/
├── workbench-init/
└── workbench-package/
```

Keep the skill directories and their assets intact, and leave the existing `grilling` installation unchanged. For an agent that uses a different skill-discovery location, place the same two folders together in that location. The instructions and relative asset links do not depend on a vendor-specific directory.

Skills are reusable user-level capabilities; generated project behavior lives in the project's root `AGENTS.md`. The workbench does not create a `.github` directory or install skills into each project. Use an agent configured to discover the installed skills and read project `AGENTS.md` instructions.

This repository contains design artifacts, not a live analytical project. Its `CONTEXT.md` and `docs/` design records are not project scaffolding. Initialization creates the workbench's own `foundation/glossary.md` when terminology is established.

## Use

In the target project's agent session, explicitly request:

> Use workbench-init to initialize this analytics project. The initial question is …

Continue analytical work normally using the generated AGENTS.md instructions. The default data flow is independent source landing, validated Parquet datasets, and DuckDB views loaded into separate analytical sessions. Data gathering never writes directly into the canonical database as its only retained representation.

When a package is needed:

> Use workbench-package to prepare a draft for the active investigation.

The skill asks which datasets to include. Subsequent requests revise the same draft. Explicitly marking it delivered preserves the next numbered release; drafting alone does not release it. M365 receives the complete narrative, chosen exports, and assembly instructions for presentation work.

## Design and validation

The [specification](docs/workbench-spec.md) defines the workflow and acceptance scenarios. The [design notes](docs/workbench-design.md) preserve the decisions behind it. Backend exceptions and exact cache-retention mechanics remain project-specific choices.

Validation completed for the first draft:

- Skill frontmatter and relative asset links passed checks. The packaging skill retains the optional `disable-model-invocation: true` hint for hosts that support it; the instructions require an explicit packaging request regardless of host support. The core skill validator was run on a temporary copy without that optional field.
- An isolated agent initialized an empty project without a question or data, then reran initialization after a README customization. The customization survived and the second pass changed no files.
- Another isolated agent refreshed a synthetic existing package with a finding awaiting revalidation. It updated the same draft, retained the empty dataset selection, added caveats beside the finding in both narratives, and preserved the numbered release, source inputs, code, and investigation records unchanged.

These checks exercised the instructions with agents and local fixtures. They do not replace a first run in your work machine's agent environment; no API acquisition, production data conversion, or M365 assembly was performed here. After repackaging under `.agents/skills/`, relative links and archive contents were rechecked, and the generated vendor-specific instruction pointer was removed.
